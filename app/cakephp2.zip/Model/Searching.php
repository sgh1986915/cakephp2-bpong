<?php
class Searching extends AppModel
{
    var $name = 'Searching';
    var $useTable = false;

}
?>