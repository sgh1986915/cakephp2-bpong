<?php
class Obj extends AppModel
{
    var $name = 'Obj';
    var $useTable = 'objects';

}
?>