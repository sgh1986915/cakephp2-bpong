<?php

class Onlinegame extends AppModel
{

    var $name     = 'Onlinegame';
    var $useTable = false;



}
?>