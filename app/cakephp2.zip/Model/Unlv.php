<?php
class Unlv extends AppModel
{

    var $name     = 'Unlv';
    var $useTable = false;

    

}

?>
