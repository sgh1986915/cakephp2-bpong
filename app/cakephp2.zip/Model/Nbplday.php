<?php
class Nbplday extends AppModel
{
    var $name = 'Nbplday';
    var $recursive = -1;

}
