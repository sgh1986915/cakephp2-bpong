<?php
class Checkout extends AppModel
{

    var $name = 'Checkout';
    var $useTable = false;

}
?>