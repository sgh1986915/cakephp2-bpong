<?php
class DeliveryStatus extends AppModel
{
    var $name = 'DeliveryStatus';
}
?>