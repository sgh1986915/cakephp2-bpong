<?php
class Option extends AppModel
{
    var $name = 'Option';

}
?>