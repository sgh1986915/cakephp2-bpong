<?php

class Eventstructure extends AppModel
{
    var $name = 'Eventstructure';
    var $useTable  = 'eventstructures';
}
?>
