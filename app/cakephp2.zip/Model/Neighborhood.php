<?php
class Neighborhood extends AppModel
{
    var $name = 'Neighborhood';
      
    /*     var $belongsTo = array(
      'City' => array('className' => 'City',
                              'foreignKey' => 'city_id');
          )   
    );          */
}
?>
