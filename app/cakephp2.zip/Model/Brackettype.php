<?php
class Brackettype extends AppModel
{
    var $name = 'Brackettype';
    var $useTable = 'brackettypes';
}
?>
