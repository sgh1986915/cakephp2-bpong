<?php
class Test extends AppModel
{

    var $name     = 'Test';
    var $useTable = false;



}

?>
