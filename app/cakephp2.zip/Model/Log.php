<?php
class Log extends AppModel
{

    var $name = 'Log';
    var $useTable = false; 
}
?>