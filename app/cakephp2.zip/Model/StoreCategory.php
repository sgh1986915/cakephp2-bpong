<?php
class StoreCategory extends AppModel
{

    var $name = 'StoreCategory';


}

?>
