<?php
class Country extends AppModel
{
    var $name = 'Country';
}
?>