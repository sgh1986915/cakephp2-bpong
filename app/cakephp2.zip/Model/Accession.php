<?php

class Accession extends AppModel
{

    var $name     = 'Accession';
    var $useTable = 'access';

    

}
