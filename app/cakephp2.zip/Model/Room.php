<?php
class Room extends AppModel
{
    var $name = 'Room';
    var $_schema = array();



    
}
?>
