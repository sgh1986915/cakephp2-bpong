<?php

class UserHistory extends AppModel
{

    var $name     = 'UserHistory';
    var $recursive = -1;
}
