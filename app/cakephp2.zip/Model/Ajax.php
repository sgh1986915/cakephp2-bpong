<?php
class Ajax extends AppModel
{
    var $name     = 'Ajax';
    var $useTable = false;
}
?>
