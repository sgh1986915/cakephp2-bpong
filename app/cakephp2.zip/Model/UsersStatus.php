<?php
class UsersStatus extends AppModel
{
    var $belongsTo = array('User', 'Status');
}
?>