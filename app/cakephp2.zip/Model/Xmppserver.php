<?php
class Xmppserver extends AppModel
{
    var $name     = 'Xmppserver';
    //function test() {return 1;}
}  
?>
