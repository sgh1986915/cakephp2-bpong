<?php
class Chatroom extends AppModel
{
    
    var $name = 'Chatroom';
                                                    
}
?>
