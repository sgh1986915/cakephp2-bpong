<?php

class ModelsTagsController extends AppController
{
    var $name = 'ModelsTags';
    var $uses    = array('ModelsTag');


}
?>
