<?php 
class BanneddevicesController extends AppController
{

    var $name = 'Banneddevices';
    var $uses = array('Banneddevice');
    
}
