<?php
class RegionsController extends AppController
{
    var $name = 'Regions';
    var $uses = array('User','Region');

}
  
?>
