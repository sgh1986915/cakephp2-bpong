<?php

class SearchingsController extends AppController
{
    var $name = 'Searchings';
    /**
* 
     * Search  by site in the Google
     * @author vovich
     * @param 
     *
     */
    function index() 
    {

                

    }
    
}//PongtablesController

?>